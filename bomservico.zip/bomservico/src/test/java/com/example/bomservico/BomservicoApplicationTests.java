package com.example.bomservico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BomservicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
