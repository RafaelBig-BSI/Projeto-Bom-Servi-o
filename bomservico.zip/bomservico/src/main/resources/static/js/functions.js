
//funções PRESTADOR
function gravarPrestador()
{
	//event.preventDefault();
	var fdados = document.getElementById("fprest");
	 var jsontext = JSON.stringify(Object.fromEntries(new FormData(fdados)));
    fetch("/cadastrarPrestador", {headers: {'Accept': 'application/json','Content-Type': 'application/json'},
                        method: 'POST', 
                        body: jsontext})
    .then(function (response) {
        return response.text(); })
    .then(function (text) {
        // result recebe a resposta do módulo dinâmico
        limparFormP();
        //pesquisar();
    }).catch(function (error) {
        console.error(error);
    });
}

function validarL()
{
	//event.preventDefault();
	var fdados = document.getElementById("fdados");
	var jsontext = JSON.stringify(Object.fromEntries(new FormData(fdados)));
    fetch("validarLogin", {headers: {'Accept': 'application/json','Content-Type': 'application/json'},
                        method: 'POST', 
                        body: jsontext})
    .then(function (response) {
        return response.text(); })
    .then(function (text) {
        // result recebe a resposta do módulo dinâmico
        limparFormL();
        //pesquisar();
    }).catch(function (error) {
        console.error(error);
    });
}

function limparFormP()
{
	var fdados = document.getElementById("fprest");
    //fdados.reset();
    fdados.cod.value=0;
    fdados.nome.value="";
    fdados.email.value="";
    fdados.senha.value="";
    fdados.endereco.value="";
    //document.getElementById("mensagem").innerHTML="";
}

function apagarMensagem()
{
    document.getElementById("mensagem").style.display="none";
}

function limparFormL()
{
	var fdados = document.getElementById("fdados");
    //fdados.reset();
    fdados.email.value="";
    fdados.senha.value="";
    fdados.opcao.value="";
    //document.getElementById("mensagem").innerHTML="";
}