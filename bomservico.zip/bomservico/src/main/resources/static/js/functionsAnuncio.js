function gravarComFoto()
{
	var fdados=document.getElementById("fanunc");
	fetch("/uploadFileData", {method:'POST', body:new FormData(fdados)})
	.then(function(response){
		return response.text();})
	.then(function(text){
	 //result recebe a resposta do modulo dinamico
	 limparFormA();
	 carregarTabelaAnuncio();
	}).catch(function(error){
	   console.error(error);
	});
}

function carregarTabelaAnuncio()
{
	const data = new URLSearchParams();
    data.append("fitro","");
    fetch("/listarAnuncio", {method: 'POST', body: data})
    .then(function (response) {
        return response.text();})
    .then(function (text) {
        var json=JSON.parse(text);
        var table="";
        for (let i=0;i<json.length;i++)
        table+=`<tr>
        			<td>${json[i].cod}</td>
        		    <td>${json[i].titulo}</td>
        		    <td>${json[i].descricao}</td>
        		    <td>${json[i].categoria.tipo}</td>
        		    <td>R$${json[i].preco}.00</td>
        		    <td>${json[i].horario}</td>
        		    <td>${json[i].contato}</td>
        		    <td>${json[i].regiao.uf}</td>
        		    <td>${json[i].foto1}</td>
        		    <td>${json[i].foto2}</td>
        		    <td>${json[i].foto3}</td>
        		    
                    <td onclick='apagarAnuncio(${json[i].cod})'>X</td>
                    </tr>`;
        document.getElementById("anuntable").innerHTML=table;
    }).catch(function (error) {
        console.error(error);
    });
}


function limparFormA()
{
	var fadados = document.getElementById("fanunc");
	fdados.cod.value=0;
	fdados.titulo.value="";
	fdados.descricao.value="";
	fdados.categoria.value="";
	fdados.preco.value="";
	fdados.horario.value="";
	fdados.contato.value="";
	fdados.foto1.value="";
	fdados.foto2.value="";
	fdados.foto3.value="";
}