

function CarregarCombosReg()
{
	fetch("/carregarCombosRegiao",{method:'get'}).then(function(response)
    {
        response.text().then(function(result)  //response é um promisse
        {
            // result contém a resposta do módulo dinâmico
            document.getElementById('regiao').innerHTML = result;
        });
    }).catch (function(err) {console.error(err);});
}