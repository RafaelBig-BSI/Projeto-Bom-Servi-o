
function gravarCategoria()
{
	var fdados = document.getElementById("fadmin");
	var jsontext = JSON.stringify(Object.fromEntries(new FormData(fdados)));
    fetch("/cadastrarCategoria", {headers: {'Accept': 'application/json','Content-Type': 'application/json'},
                        method: 'POST', 
                        body: jsontext})
    .then(function (response) {
        return response.text(); })
    .then(function (text) {
        // result recebe a resposta do módulo dinâmico
        limparFormC();
        pesquisarCategoria();
    }).catch(function (error) {
        console.error(error);
    });
}

function pesquisarCategoria()
{
    const data = new URLSearchParams();
    data.append("fitro","");
    fetch("/listarCategoria", {method: 'POST', body: data})
    .then(function (response) {
        return response.text();})
    .then(function (text) {
        var json=JSON.parse(text);
        var table="";
        for (let i=0;i<json.length;i++)
        table+=`<tr>
        			<td>${json[i].cod}</td>
        			<td>${json[i].tipo}</td>
        			
                    <td onclick='apagarCategoria(${json[i].cod})'>X</td>
                    <td onclick='alterarCategoria(${json[i].cod})'>▓</td>
                    </tr>`;
        document.getElementById("pesqCat").innerHTML=table;
    }).catch(function (error) {
        console.error(error);
    });
}

function apagarCategoria(cod)
{
    fetch("/apagarCat?cod="+cod, {method: 'GET'})
    .then(function (response) {
        return response.text();})
    .then(function (text) {
        limparFormC();
        pesquisarCategoria();
        var divm=document.getElementById("mensagem");
        divm.innerHTML=text;
        divm.style.display="block";
        setTimeout(apagarMensagem, 2000); 
    }).catch(function (error) {
        console.error(error);
    });
}

function alterarCategoria(cod)
{   var fdados = document.getElementById("fadmin");
    fetch("/buscarCat?cod="+cod, {method: 'GET'})
    .then(function (response) {
        return response.text();})
    .then(function (text) {
        var json=JSON.parse(text);
        fdados.cod.value=json.cod;
        fdados.nome.value=json.tipo;
        pesquisarCategoria();
    }).catch(function (error) {
        console.error(error);
    });
}

function limparFormC()
{
    var fdados = document.getElementById("fadmin");
    //fdados.reset();
    fdados.cod.value=0;
    fdados.nome.value="";
    //document.getElementById("mensagem").innerHTML="";
}

function apagarMensagem()
{
    document.getElementById("mensagem").style.display="none";
}

function CarregarCombos()
{
	fetch("/carregarCombos",{method:'get'}).then(function(response)
    {
        response.text().then(function(result)  //response é um promisse
        {
            // result contém a resposta do módulo dinâmico
            document.getElementById('categoria').innerHTML = result;
        });
    }).catch (function(err) {console.error(err);});
}