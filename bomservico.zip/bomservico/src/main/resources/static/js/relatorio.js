

function emitirRel()
{
	fetch("geraRelatorio",{method:'get'}).then(function(response)
    {
        response.text().then(function(result)  //response é um promisse
        {
            // result contém a resposta do módulo dinâmico
            //document.getElementById('rel').innerHTML = result;
        });
    }).catch (function(err) {console.error(err);});
}