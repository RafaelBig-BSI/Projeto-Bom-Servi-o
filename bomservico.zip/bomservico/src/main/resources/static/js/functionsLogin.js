
function validar()
{
	var fdados = document.getElementById("flogin");
	var jsontext = JSON.stringify(Object.fromEntries(new FormData(fdados)));
    fetch("/validarLogin", {headers: {'Accept': 'application/json','Content-Type': 'application/json'},
                        method: 'POST', 
                        body: jsontext})
    .then(function (response) {
        return response.text(); })
    .then(function (text) {
        // result recebe a resposta do módulo dinâmico
        limparFormLogin();
    }).catch(function (error) {
        console.error(error);
    });
}

function limparFormLogin()
{
	var fdados = document.getElementById("flogin");
    //fdados.reset();
    fdados.email.value="";
    fdados.senha.value="";
    fdados.opcao.value="";
    //document.getElementById("mensagem").innerHTML="";
}