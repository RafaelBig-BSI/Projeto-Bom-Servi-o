package com.example.bomservico.bd.util;

import java.util.List;

import com.example.bomservico.bd.dal.DALPrestador;
import com.example.bomservico.bd.entidade.Prestador;

public class Login 
{
	public Login() {
	}
	
	public boolean validarLogin(String email, String senha, int tipoU)
	{
		boolean emailValido=false;
		List<Prestador> listaprest = new DALPrestador().getPrestadorSemFiltro();
		
		if(email.length() > 0 && senha.length() > 0 && tipoU <=2)
		{
			for(Prestador p : listaprest)
				if(p.getEmail().contains(email) && p.getSenha().contains(senha) && p.getTipoUsuario() == tipoU)
						emailValido = true;
		}
		
		return emailValido;
	}
}
