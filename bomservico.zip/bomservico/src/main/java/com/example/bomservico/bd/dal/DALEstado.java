package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Estado;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALEstado 
{
	public boolean salvar(Estado est)
    {
        String sql="insert into estado (uf) values ('$1')";
        sql=sql.replace("$1",est.getUf());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Estado est)
    {
        String sql="update estado set uf='$1' where cod="+est.getCod();
        sql=sql.replace("$1",est.getUf());
        
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from estado where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Estado getEstado(int cod)
    {
        Estado est=null;
        String sql="select * from estado where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                est = new Estado(rs.getInt("cod"), rs.getString("uf"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return est;
    }
    
    public ArrayList <Estado> getEstado(String filtro)
    {
        ArrayList <Estado> lista = new ArrayList();
        String sql="select * from estado";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by uf";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Estado(rs.getInt("cod"), rs.getString("uf")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
