package com.example.bomservico.bd.entidade;

public class Anuncio 
{
	private int cod;
    private String descricao;
    private String horario;
    private String contato;
    private String foto1;
    private String foto2;
    private String foto3;
    private double preco;
    private Categoria categoria;
    private String titulo;
    private Regiao regiao;
    
    public Anuncio() {
        
    }

    public Anuncio(int cod, String descricao, String horario, String contato, String foto1, String foto2, String foto3, double preco, String titulo, Categoria categoria, Regiao regiao) {
        this.cod = cod;
        this.descricao = descricao;
        this.horario = horario;
        this.contato = contato;
        this.foto1 = foto1;
        this.foto2 = foto2;
        this.foto3 = foto3;
        this.preco = preco;
        this.titulo = titulo;
        this.categoria = categoria;
        this.regiao = regiao;
    }
    
    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getFoto1() {
        return foto1;
    }

    public void setFoto1(String foto1) {
        this.foto1 = foto1;
    }
    
    public String getFoto2() {
		return foto2;
	}

	public void setFoto2(String foto2) {
		this.foto2 = foto2;
	}

	public String getFoto3() {
		return foto3;
	}

	public void setFoto3(String foto3) {
		this.foto3 = foto3;
	}
    
    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public Regiao getRegiao() {
    	return regiao;
    }
    
    public void setRegiao(Regiao regiao) {
    	this.regiao = regiao;
    }
    
    @Override
    public String toString() {
        return cod + "," + descricao + "," + horario + "," + 
               contato + "," + foto1 + "," + foto2 + "," + foto3 + "," + preco + "," + 
               categoria + "," + titulo + "," + regiao;
    }
}
