package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Cidade;
import com.example.bomservico.bd.entidade.Estado;
import com.example.bomservico.bd.entidade.Localidade;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALLocalidade 
{
	public boolean salvar(Localidade loc)
    {
        String sql="insert into localidade (cidade,estado) values ('$1','$2')";
        sql=sql.replace("$1",""+loc.getCidade());
        sql=sql.replace("$2", ""+loc.getEstado());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Localidade loc)
    {
        String sql="update localidade set cidade='$1', estado='$2' where cod="+loc.getCod();
        sql=sql.replace("$1",""+loc.getCidade());
        sql=sql.replace("$2", ""+loc.getEstado());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from localidade where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Localidade getLocalidade(int cod)
    {
        Localidade loc=null;
        String sql="select * from localidade where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                loc = new Localidade(rs.getInt("cod"), 
                                    (Cidade)rs.getObject("cidade"), (Estado)rs.getObject("estado"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return loc;
    }
    
    public ArrayList <Localidade> getLocalidade(String filtro)
    {
        ArrayList <Localidade> lista = new ArrayList();
        String sql="select * from localidade";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by cidade";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Localidade(rs.getInt("cod"),
                                        (Cidade)rs.getObject("cidade"), (Estado)rs.getObject("estado")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
