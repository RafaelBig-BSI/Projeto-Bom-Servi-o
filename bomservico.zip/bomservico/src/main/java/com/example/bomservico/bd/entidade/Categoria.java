package com.example.bomservico.bd.entidade;

public class Categoria 
{
	private int cod;
    private String tipo;

    public Categoria() {
        this(0,"");
    }

    public Categoria(int cod, String tipo) {
        this.cod = cod;
        this.tipo = tipo;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @Override
    public String toString() {
        return cod + "," + tipo;
    }
}
