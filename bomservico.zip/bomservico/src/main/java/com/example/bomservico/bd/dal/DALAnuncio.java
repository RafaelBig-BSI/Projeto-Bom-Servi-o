package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Anuncio;
import com.example.bomservico.bd.entidade.Categoria;
import com.example.bomservico.bd.entidade.Prestador;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALAnuncio 
{
	public boolean salvar(Anuncio an)
    {
        String sql="insert into anuncio (descricao,horario,contato,foto1,foto2,foto3,preco,titulo,categoria,regiao) values ('$1','$2','$3','$4','$5','$6',$7,'$8',$9,$10)";
        sql=sql.replace("$1",an.getDescricao());
        sql=sql.replace("$2",an.getHorario());
        sql=sql.replace("$3", an.getContato());
        
        sql=sql.replace("$4", an.getFoto1());
        sql=sql.replace("$5", an.getFoto2());
        sql=sql.replace("$6", an.getFoto3());
        
        sql=sql.replace("$7", ""+an.getPreco());
        sql=sql.replace("$8", an.getTitulo());
        sql=sql.replace("$9", ""+an.getCategoria());
        sql=sql.replace("$10", ""+an.getRegiao());
        
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Anuncio an)
    {
        String sql="update anuncio set descricao='$1', horario='$2', contato='$3', foto1='$4', foto2='$5', foto3='$6', preco=$7, titulo='$8', categoria=$9 regiao=$10 where cod="+an.getCod();
        sql=sql.replace("$1",an.getDescricao());
        sql=sql.replace("$2",an.getHorario());
        sql=sql.replace("$3",an.getContato());
        
        sql=sql.replace("$4", an.getFoto1());
        sql=sql.replace("$5", an.getFoto2());
        sql=sql.replace("$6", an.getFoto3());
        
        sql=sql.replace("$7",""+an.getPreco());
        sql=sql.replace("$8", an.getTitulo());
        sql=sql.replace("$9",""+an.getCategoria());
        sql=sql.replace("$10", ""+an.getRegiao());
        
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from anuncio where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Anuncio getAnuncio(int cod)
    {
        Anuncio an=null;
        String sql="select * from anuncio where cod="+cod;
        
        DALCategoria dalcat = new DALCategoria();
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                an = new Anuncio(rs.getInt("cod"), rs.getString("descricao"), rs.getString("horario"), rs.getString("contato"),
                                 rs.getString("foto1"), rs.getString("foto2"), rs.getString("foto3"),
                                 rs.getDouble("preco"), rs.getString("titulo"),
                                 dalcat.getCategoria(rs.getInt("categoria")),
                                 new DALRegiao().getRegiao(rs.getInt("regiao")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return an;
    }
    
    
    
    public ArrayList <Anuncio> getAnuncio(String filtro)
    {
        ArrayList <Anuncio> lista = new ArrayList();
        String sql="select * from anuncio";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by titulo";
        
        DALCategoria dalcat = new DALCategoria();
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Anuncio(rs.getInt("cod"), rs.getString("descricao"), rs.getString("horario"), rs.getString("contato"),
				                        rs.getString("foto1"), rs.getString("foto2"), rs.getString("foto3"),
				                        rs.getDouble("preco"), rs.getString("titulo"),
				                        dalcat.getCategoria(rs.getInt("categoria")),
				                        new DALRegiao().getRegiao(rs.getInt("regiao"))));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
    
    public ArrayList <Anuncio> getAnuncioSemFiltro()
    {
        ArrayList <Anuncio> lista = new ArrayList();
        String sql="select * from anuncio";
        
        DALCategoria dalcat = new DALCategoria();
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Anuncio(rs.getInt("cod"), rs.getString("descricao"), rs.getString("horario"), rs.getString("contato"),
				                        rs.getString("foto1"), rs.getString("foto2"), rs.getString("foto3"),
				                        rs.getDouble("preco"), rs.getString("titulo"),
				                        dalcat.getCategoria(rs.getInt("categoria")),
				                        new DALRegiao().getRegiao(rs.getInt("regiao"))));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
