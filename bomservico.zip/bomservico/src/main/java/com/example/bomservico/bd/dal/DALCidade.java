package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Cidade;
import com.example.bomservico.bd.entidade.Estado;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALCidade
{
	public boolean salvar(Cidade cid)
    {
        String sql="insert into cidade (nome,estado) values ('$1','$2')";
        sql=sql.replace("$1",cid.getNome());
        sql=sql.replace("$2",""+cid.getEstado());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Cidade cid)
    {
        String sql="update cidade set nome='$1', estado='$2' where cod="+cid.getCod();
        sql=sql.replace("$1",cid.getNome());
        sql=sql.replace("$2", ""+cid.getEstado());
        
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from cidade where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Cidade getCidade(int cod)
    {
        Cidade cid=null;
        String sql="select * from cidade where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                cid = new Cidade(rs.getInt("cod"), rs.getString("nome"), (Estado)rs.getObject("estado"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return cid;
    }
    
    public ArrayList <Cidade> getCidade(String filtro)
    {
        ArrayList <Cidade> lista = new ArrayList();
        String sql="select * from cidade";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by nome";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Cidade(rs.getInt("cod"), rs.getString("nome"), (Estado)rs.getObject("estado")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
