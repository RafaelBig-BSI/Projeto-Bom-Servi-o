package com.example.bomservico.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.bouncycastle.crypto.tls.AlertDescription;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.bomservico.bd.dal.DALAnuncio;
import com.example.bomservico.bd.dal.DALCategoria;
import com.example.bomservico.bd.dal.DALPrestador;
import com.example.bomservico.bd.dal.DALRegiao;
import com.example.bomservico.bd.entidade.Anuncio;
import com.example.bomservico.bd.entidade.Categoria;
import com.example.bomservico.bd.entidade.Prestador;
import com.example.bomservico.bd.entidade.Regiao;
import com.example.bomservico.bd.util.Login;

@RestController
public class BSServiceController 
{
						/* ANUNCIO */
	@RequestMapping(value="/listarAnuncio")
	public ResponseEntity <Object> listarTodosAnuncio()
	{
		Map<String, Anuncio> mapanuncio = new HashMap<>();
		List<Anuncio> listanunc = new DALAnuncio().getAnuncioSemFiltro();
		
		for(Anuncio an : listanunc)
			mapanuncio.put(""+an.getCod(), an);
		
		return new ResponseEntity<>(mapanuncio.values(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/uploadFileData", method = RequestMethod.POST)
	public String submitFileData(@RequestParam("file") MultipartFile files[],
								 @RequestParam int cod,
								 @RequestParam String titulo, @RequestParam String descricao,
								 @RequestParam int categoria, @RequestParam double preco,
								 @RequestParam String horario, @RequestParam String contato)
	{
		String msg = "Upload com sucesso";
		Path root = Paths.get("/static/fotos");
		DALAnuncio dalan = new DALAnuncio();
		Anuncio an = new Anuncio();
		Categoria cat = new Categoria();
		
		if(cod == 0)
		{
			an.setTitulo(titulo);
			an.setDescricao(descricao);
			cat.setCod(categoria);
			an.setCategoria(cat);
			an.setPreco(preco);
			an.setHorario(horario);
			an.setContato(contato);
			
			an.setFoto1(files[0].getOriginalFilename());
			an.setFoto2(files[1].getOriginalFilename());
			an.setFoto3(files[2].getOriginalFilename());
			
			if(!dalan.salvar(an))
				msg = "erro ao gravar";
		}
		
		try
		{
			for(MultipartFile file : files)
			{
				Files.copy(file.getInputStream(), root.resolve(file.getOriginalFilename()));
			}
		}
		catch(Exception e)
		{System.out.println("Erro ao armazenar os arquivos: "+e.getMessage());}
		
		return msg;
	}
	
	@RequestMapping(value="/retornaAnuncios") //A partir de uma categoria
	public ResponseEntity<Object> retornaAnuncios(@RequestParam String categoria)
	{
		Map<String, Anuncio>mapanuncio = new HashMap<>();
		List<Anuncio>listanunc = new DALAnuncio().getAnuncioSemFiltro();
		
		for(Anuncio an : listanunc)
			if(an.getCategoria().getTipo().contains(categoria))
				mapanuncio.put(""+an.getCod(), an);
		
		return new ResponseEntity<>(mapanuncio.values(),HttpStatus.OK);
	}
	
	/*-------------------------------------------------------------*/
						/* PRESTADOR */
	@RequestMapping(value="/listarPrestador")
	public ResponseEntity <Object> listarTodosPrestador()
	{
		Map<String, Prestador>mapprestador = new HashMap<>();
		List<Prestador> listaprest = new DALPrestador().getPrestadorSemFiltro();
		
		for(Prestador p : listaprest)
			mapprestador.put(""+p.getCod(),p);
		
		return new ResponseEntity<>(mapprestador.values(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/cadastrarPrestador", method = RequestMethod.POST)
	public ResponseEntity<Object>cadPrestador(@RequestBody Prestador prestador)
	{
		String retorno="Gravado com sucesso";
		DALPrestador prest = new DALPrestador();
		prestador.setTipoUsuario(2);
		
		if(prestador.getCod()==0)
		{		
			if(!prest.salvar(prestador))
				retorno = "Erro ao gravar";
		}
		
		else
		{
			int i=0;
			DALPrestador dalp = new DALPrestador();
			List<Prestador> listap = new DALPrestador().getPrestadorSemFiltro();
			retorno = "Alterado com sucesso";
			
			while(listap.get(i) .getCod() != prestador.getCod())
			    i++;
			
			if(i < listap.size())
			{
				listap.set(i, prestador);
				
				if(!dalp.alterar(prestador))
					retorno = "Problemas ao alterar";
			}
			else
				retorno="Erro ao localizar";
		}
		
		return new ResponseEntity<>(retorno,HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/validarLogin", method = RequestMethod.GET)
	public void login(ModelMap model,HttpServletRequest request, HttpServletResponse response)
												throws ServletException, IOException
	{
		String email="", senha="";
		int tipoU = 0;
        boolean retorno = false;
        HttpSession sessao = request.getSession(true);
        
        try
        {
        	email = request.getParameter("email");
        	senha = request.getParameter("senha");
        	tipoU = Integer.parseInt(request.getParameter("opcao"));
        }
        catch(Exception e)
        { }
        
        try
        {
        	Login login = new Login();
        	retorno = login.validarLogin(email, senha, tipoU);
        	
        	if(retorno == true && tipoU == 1)
        	{
        		sessao.setAttribute("email", login);
        		response.sendRedirect("http://localhost:8080/html/Admin.html");
        	}
        	
        	if(retorno == true && tipoU == 2)
        	{
        		sessao.setAttribute("email", login);
        		response.sendRedirect("http://localhost:8080/html/Anuncio.html");
        	}
        	
        	if(retorno == false)
        	{
        		response.sendRedirect("http://localhost:8080/html/Login.html");
        	}
        		
        }
        catch(Exception e)
        {}
	}
	
//	@RequestMapping(value="/validarLogin", method = RequestMethod.GET)
//	public String login(ModelMap model,HttpServletRequest request) {
//
//	    String referrer = request.getHeader("Referer");
//	    
//	    if(referrer!=null)
//	    {
//	        request.getSession().setAttribute("url_prior_login", referrer);
//	    }
//	    
//	    return "user/login";
//	}
	
	
	
	
	/*-------------------------------------------------------------*/
						/* 	CATEGORIA */
	@RequestMapping(value="/listarCategoria")
	public ResponseEntity <Object> listarTodasCategoria()
	{
		Map<String, Categoria>mapcategoria= new HashMap<>();
		List<Categoria> listacat = new DALCategoria().getCategoriaSemFiltro();
		
		for(Categoria c : listacat)
			mapcategoria.put(""+c.getCod(), c);
		
		return new ResponseEntity<>(mapcategoria.values(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/cadastrarCategoria", method = RequestMethod.POST)
	public ResponseEntity<Object>cadCategoria(@RequestBody Categoria categoria)
	{
		String retorno="Gravado com sucesso";
		DALCategoria cat = new DALCategoria();
		
		if(categoria.getCod()==0)
		{		
			if(!cat.salvar(categoria))
				retorno = "Erro ao gravar";
		}
		
		else
		{
			int i=0;
			DALCategoria dalc = new DALCategoria();
			List<Categoria> listac = new DALCategoria().getCategoriaSemFiltro();
			retorno = "Alterado com sucesso";
			
			while(listac.get(i) .getCod() != categoria.getCod())
			    i++;
			
			if(i < listac.size())
			{
				listac.set(i, categoria);
				
				if(!dalc.alterar(categoria))
					retorno = "Problemas ao alterar";
			}
			else
				retorno="Erro ao localizar";
			
		}
		
		return new ResponseEntity<>(retorno,HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/apagarCat")	
	public ResponseEntity <Object> apagarCat(@RequestParam(value="cod") int cod)
	{
		List<Categoria> listacat = new DALCategoria().getCategoriaSemFiltro();
		String retorno="problemas ao apagar";
		DALCategoria dalcat = new DALCategoria();
		
		for (Categoria categoria : listacat)
		  if (categoria.getCod()==cod)
		  { 
	            	listacat.remove(categoria);
	            	dalcat.apagar(categoria.getCod());
	            	retorno="Excluído com sucesso";
	         break;
	      }
		return new ResponseEntity<>(retorno,HttpStatus.OK); 	
	}
	
	@RequestMapping(value="/buscarCat")	
	public ResponseEntity <Object> alterarCat(@RequestParam(value="cod") int cod)
	{   
		List <Categoria> listacat = new DALCategoria().getCategoriaSemFiltro();
		Categoria categoria = new Categoria();
		
	    for (Categoria cat : listacat)
	         if (cat.getCod()==cod) 
	        	 categoria = cat;
	         

	    return new ResponseEntity<>(categoria,HttpStatus.OK);	
	}
	
	@RequestMapping(value="/carregarCombos")
	public ResponseEntity <Object> carregaCB()
	{
		String res="";
		List<Categoria> listacat = new DALCategoria().getCategoriaSemFiltro();
		
		for(Categoria c : listacat)
		{
			res += String.format("<option value="+c.getCod()+">"+ c.getTipo()+"</option>");
		}
		
		return new ResponseEntity<>(res, HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/carregarCombosRegiao")
	public ResponseEntity <Object> carrega()
	{
		String res="";
		List<Regiao> listareg = new DALRegiao().getRegiaoSemFiltro();
		
		for(Regiao reg : listareg)
		{
			res += String.format("<option value="+reg.getCod()+">"+ reg.getUf()+"</option>");
		}
		
		return new ResponseEntity<>(res, HttpStatus.OK);
		
	}
}
