package com.example.bomservico.bd.entidade;

public class Localidade
{
	private int cod;
    private Cidade cidade;
    private Estado estado;

    public Localidade() {
    }

    public Localidade(int cod, Cidade cidade, Estado estado) {
        this.cod = cod;
        this.cidade = cidade;
        this.estado = estado;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    @Override
    public String toString() {
        return cod + "," + cidade + "," + estado;
    }
}
