package com.example.bomservico.bd.dal;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.bomservico.bd.entidade.Regiao;
import com.example.bomservico.bd.util.Conexao;

public class DALRegiao 
{
	public Regiao getRegiao(int cod)
    {
        Regiao reg=null;
        String sql="select * from regiao where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                reg = new Regiao(rs.getInt("cod"), rs.getString("uf"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return reg;
    }
    
    public ArrayList <Regiao> getRegiao(String filtro)
    {
        ArrayList <Regiao> lista = new ArrayList();
        String sql="select * from regiao";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by uf";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Regiao(rs.getInt("cod"), rs.getString("uf")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
    
    public ArrayList <Regiao> getRegiaoSemFiltro()
    {
        ArrayList <Regiao> lista = new ArrayList();
        String sql="select * from regiao";
        
        sql+=" order by uf";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Regiao(rs.getInt("cod"), rs.getString("uf")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
