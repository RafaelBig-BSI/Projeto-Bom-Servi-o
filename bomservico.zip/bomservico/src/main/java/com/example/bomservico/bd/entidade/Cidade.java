package com.example.bomservico.bd.entidade;

public class Cidade 
{
	private int cod;
    private String nome;
    private Estado estado;
    
    public Cidade() {
        
    }

    public Cidade(int cod, String nome, Estado estado) {
        this.cod = cod;
        this.nome = nome;
        this.estado = estado;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    @Override
    public String toString() {
        return cod + "," + nome + "," + estado;
    }
}
