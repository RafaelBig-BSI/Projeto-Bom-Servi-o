package com.example.bomservico.bd.entidade;

public class Estado
{
	private int cod;
    private String uf;
    
    public Estado() {
    }

    public Estado(int cod, String uf) {
        this.cod = cod;
        this.uf = uf;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
    
    @Override
    public String toString() {
        return cod + "," + uf;
    }
}
