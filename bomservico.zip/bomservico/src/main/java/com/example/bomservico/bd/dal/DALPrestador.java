package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Prestador;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALPrestador
{
	public boolean salvar(Prestador pr)
    {
        String sql="insert into prestador(nome,email,senha,endereco,tipoUsuario) values('$1','$2','$3','$4', $5)";
        sql=sql.replace("$1",pr.getNome());
        sql=sql.replace("$2",pr.getEmail());
        sql=sql.replace("$3",pr.getSenha());
        sql=sql.replace("$4",pr.getEndereco());
        sql=sql.replace("$5",""+pr.getTipoUsuario());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Prestador pr)
    {
        String sql="update prestador set nome='$1', email='$2', senha='$3', endereco='$4', tipoUsuario=$5 where cod="+pr.getCod();
        sql=sql.replace("$1",pr.getNome());
        sql=sql.replace("$2",pr.getEmail());
        sql=sql.replace("$3",pr.getSenha());
        sql=sql.replace("$4",pr.getEndereco());
        sql=sql.replace("$5",""+pr.getTipoUsuario());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from prestador where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Prestador getPrestador(int cod)
    {
        Prestador pr=null;
        String sql="select * from prestador where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                pr = new Prestador(rs.getInt("cod"), rs.getString("nome"), rs.getString("email"), 
                                   rs.getString("senha"), rs.getString("endereco"),
                                   rs.getInt("tipoUsuario"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return pr;
    }
    
    public ArrayList <Prestador> getPrestador(String filtro)
    {
        ArrayList <Prestador> lista = new ArrayList();
        String sql="select * from prestador";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by nome";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Prestador(rs.getInt("cod"), rs.getString("nome"), rs.getString("email"),
                                        rs.getString("senha"), rs.getString("endereco"),
                                        rs.getInt("tipoUsuario")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
    
    public ArrayList <Prestador> getPrestadorSemFiltro()
    {
        ArrayList <Prestador> lista = new ArrayList();
        String sql="select * from prestador";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Prestador(rs.getInt("cod"), rs.getString("nome"), rs.getString("email"),
                                        rs.getString("senha"), rs.getString("endereco"),
                                        rs.getInt("tipoUsuario")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
    
    public Prestador getPrestadorEmail(String email)
    {
    	Prestador pr=null;
        String sql="select email from prestador where email="+email;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                pr = new Prestador(rs.getInt("cod"), rs.getString("nome"), rs.getString("email"), 
                                   rs.getString("senha"), rs.getString("endereco"),
                                   rs.getInt("tipoUsuario"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return pr;
    }
}
