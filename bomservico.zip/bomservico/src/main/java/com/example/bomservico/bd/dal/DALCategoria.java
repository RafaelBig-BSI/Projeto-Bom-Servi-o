package com.example.bomservico.bd.dal;

import com.example.bomservico.bd.entidade.Categoria;
import com.example.bomservico.bd.entidade.Prestador;
import com.example.bomservico.bd.util.Conexao;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DALCategoria 
{
	public boolean salvar(Categoria cat)
    {
        String sql="insert into categoria (cod,tipo) values (default,'$1')";
        sql=sql.replace("$1",cat.getTipo());
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean alterar(Categoria cat)
    {
        String sql="update categoria set tipo='$1' where cod="+cat.getCod();
        sql=sql.replace("$1",cat.getTipo());
        
        Conexao con = new Conexao();
        boolean flag=con.manipular(sql);
        con.fecharConexao();
        return flag;
    }
    
    public boolean apagar(int cod)
    {
        Conexao con = new Conexao();
        boolean flag=con.manipular("delete from categoria where cod="+cod);
        con.fecharConexao();
        return flag;
    }
    
    public Categoria getCategoria(int cod)
    {
        Categoria cat=null;
        String sql="select * from categoria where cod="+cod;
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            if(rs.next())
                cat = new Categoria(rs.getInt("cod"), rs.getString("tipo"));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return cat;
    }
    
    public ArrayList <Categoria> getCategoria(String filtro)
    {
        ArrayList <Categoria> lista = new ArrayList();
        String sql="select * from categoria";
        
        if(!filtro.isEmpty())
            sql+=" where "+filtro;
        sql+=" order by tipo";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Categoria(rs.getInt("cod"), rs.getString("tipo")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
    
    public ArrayList <Categoria> getCategoriaSemFiltro()
    {
        ArrayList <Categoria> lista = new ArrayList();
        String sql="select * from categoria";
        
        Conexao con = new Conexao();
        ResultSet rs = con.consultar(sql);
        
        try
        {
            while(rs.next())
                lista.add(new Categoria(rs.getInt("cod"), rs.getString("tipo")));
        }
        catch(Exception e)
        {System.out.println(e.getMessage());}
        
        con.fecharConexao();
        return lista;
    }
}
