package com.example.bomservico.bd.entidade;

public class Prestador 
{
	private int cod;
    private String nome;
    private String email;
    private String senha;
    private String endereco;
    private int tipoUsuario;
    
	public Prestador() {
		this(0,"","","","",0);
    }

    public Prestador(int cod, String nome, String email, String senha, String endereco, int tipoUsuario) {
        this.cod = cod;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
        this.tipoUsuario = tipoUsuario;        
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    public int getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(int tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
    
    @Override
    public String toString() {
        return cod + "," + nome + "," +
               email + "," + senha + "," +
               endereco + "," + tipoUsuario;
    }
}
